#!d:\自己用\项目\python\python从入门到精通\learning_log\ll_env\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
